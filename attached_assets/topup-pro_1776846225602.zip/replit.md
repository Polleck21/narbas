# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Top Up Game Store — integrated with Digiflazz (product provider) and Midtrans (payment gateway).

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite, TailwindCSS, Framer Motion, Wouter, React Query
- **Payment**: Midtrans Snap (payment popup)
- **Product provider**: Digiflazz (game top up products)

## Artifacts

- `artifacts/topup-store` — React + Vite frontend, serves at `/`
- `artifacts/api-server` — Express API server, serves at `/api`

## Key Features

- Game product catalog (Mobile Legends, Free Fire, PUBG, COD Mobile, Genshin Impact, Valorant)
- Denomination selection per game
- Order creation flow with Midtrans Snap payment popup
- Order status tracking (`/order/:orderId`)
- Check order by reference ID (`/cek-pesanan`)
- Digiflazz top-up triggered automatically on payment success (Midtrans webhook)

## Environment Variables / Secrets Required

- `DIGIFLAZZ_USERNAME` — Digiflazz account username
- `DIGIFLAZZ_API_KEY` — Digiflazz API key
- `MIDTRANS_SERVER_KEY` — Midtrans server key (backend)
- `MIDTRANS_CLIENT_KEY` — Midtrans client key (backend)
- `VITE_MIDTRANS_CLIENT_KEY` — Midtrans client key (frontend env var, for Snap popup)
- `DATABASE_URL` — PostgreSQL connection string (auto-provisioned)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)

## Database Tables

- `products` — game catalog (game_code, game_name, category, image_url, etc.)
- `denominations` — top-up amounts per game (product_code, selling_price, etc.)
- `orders` — customer orders with payment and fulfillment status

## Notes

- Codegen script patches `lib/api-zod/src/index.ts` after orval runs to avoid duplicate exports from types barrel
- Midtrans uses Sandbox mode in development, production in NODE_ENV=production
- Digiflazz top-up is triggered in the Midtrans notification webhook at `/api/payment/notification`
